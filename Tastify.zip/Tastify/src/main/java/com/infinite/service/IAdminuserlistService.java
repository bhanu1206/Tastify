package com.infinite.service;

import java.util.List;

import com.infinite.model.User;

public interface IAdminuserlistService {
	public List<User> getUsers();

}
